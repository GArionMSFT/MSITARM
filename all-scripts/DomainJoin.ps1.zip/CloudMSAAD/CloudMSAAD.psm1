﻿
$PSScriptRoot = Split-Path -parent $MyInvocation.MyCommand.Definition

	# Import ADAL library to acquire access token
	# $PSScriptRoot only work PowerShell V3 or above versions
	Add-Type -Path "$PSScriptRoot\Microsoft.IdentityModel.Clients.ActiveDirectory.dll"
	Add-Type -Path "$PSScriptRoot\Microsoft.IdentityModel.Clients.ActiveDirectory.Platform.dll"


Function Invoke-AzureRestGetAPI
{
	[CmdletBinding()]
	Param
	(
        [Parameter(Mandatory=$true)][String]$uri,
		[Parameter(Mandatory=$true)][String]$clientId,
        [Parameter(Mandatory=$true)][String]$key,
        [Parameter(Mandatory=$true)][String]$tenantId
	)

	# import the module to help to compose the auth header
	#Import-Module '.\NewAzureAuthRestHeader.psm1'
	
	# compose auth header for rest call
	$authHeader = New-AzureRestAuthorizationHeader -ClientId $clientId -ClientKey $key -TenantId $tenantId

	# invoke rest call
	Return Invoke-RestMethod -Method Get -Headers $authHeader -Uri $Uri
}

Function Invoke-AzureRestPostAPI
{
	[CmdletBinding()]
	Param
	(
		[Parameter(Mandatory=$true)][String]$Uri,
        [Parameter(Mandatory=$true)][String]$clientId,
        [Parameter(Mandatory=$true)][String]$key,
        [Parameter(Mandatory=$true)][String]$tenantId,
		[Parameter(Mandatory=$true)][String]$Body
	)

	# import the module to help to compose the auth header
	#Import-Module '.\NewAzureAuthRestHeader.psm1'
	
	# compose auth header for rest call
	$authHeader = New-AzureRestAuthorizationHeader -ClientId $clientId -ClientKey $key -TenantId $tenantId

	# invoke rest call
	Return Invoke-RestMethod -Method Post -Headers $authHeader -Uri $Uri -Body $Body
}

Function New-AzureRestAuthorizationHeader
{
	[CmdletBinding()]
	Param
	(
		[Parameter(Mandatory=$true)][String]$ClientId,
		[Parameter(Mandatory=$true)][String]$ClientKey,
		[Parameter(Mandatory=$true)][String]$TenantId
	)

	# Authorization & resource Url
	$authUrl = "https://login.windows.net/$TenantId/"
	$resource = "https://management.core.windows.net/"

	# Create credential for client application
	$clientCred = [Microsoft.IdentityModel.Clients.ActiveDirectory.ClientCredential]::new($ClientId, $ClientKey)

	# Create AuthenticationContext for acquiring token
	$authContext = [Microsoft.IdentityModel.Clients.ActiveDirectory.AuthenticationContext]::new($authUrl, $false)
  #  write-output "AuthContext: $authContext"

	# Acquire the authentication result
	$authResult = $authContext.AcquireTokenAsync($resource, $clientCred).Result
   # write-output "AuthResult: $authResult"

	# Compose the access token type and access token for authorization header
	$authHeader = $authResult.AccessTokenType + " " + $authResult.AccessToken
    #write-output "AuthHeader: $authHeader"

	# the final header hash table
	return @{"Authorization"=$authHeader; "Content-Type"="application/json"}
}


Export-ModuleMember -Function "*"


