﻿#######
#
<#

Import-Module .\Add-OmsWorkspace.psm1 -Force

Import-Module \\crom\C$\Users\<Your username>\Source\Repos\PowerShell\Add-OmsWorkspace.psm1 -Force


$primaryWorkspaceID = '7388eb86-8c68-4d19-ae90-18e9a8235d5d'
$primaryWorkspaceKey = '<supa secret keys>'
$secondaryWorkspaceID = '0f00ef94-f80f-4165-81d6-f417b8000a15'
$secondaryWorkspaceKey = '<supa secret keys>'
$VerbosePreference = 'Continue'

Set-OMSWorkspaces $primaryWorkspaceID $primaryWorkspaceKey
Set-OMSWorkspaces $primaryWorkspaceID $primaryWorkspaceKey $secondaryWorkspaceID $secondaryWorkspaceKey
Set-OMSWorkspaces $null $null $secondaryWorkspaceID $secondaryWorkspaceKey
Set-OMSWorkspaces $null $null $null $null



Test-OMSWorkspaces $primaryWorkspaceID $null
Test-OMSWorkspaces $primaryWorkspaceID $secondaryWorkspaceID 
Test-OMSWorkspaces $null  $secondaryWorkspaceID
Test-OMSWorkspaces $null $null 


testing stuff
$healthService.RemoveCloudWorkspace($primaryWorkspaceID)
$healthService.RemoveCloudWorkspace($secondaryWorkspaceID)
$healthService.ReloadConfiguration();$healthService = $null;$healthService = New-Object -ComObject 'AgentConfigManager.MgmtSvcCfg'


#>
function Test-OMSWorkspaces {
	param(
		[string] $primaryWorkspaceID,
		[string] $secondaryWorkspaceID
	    )
	$returnedStatus = $true
	# bail out quick if the customer doesn't want monitoring
	if(!$primaryWorkspaceID -and !$secondaryWorkspaceID){write-verbose "Customer doen't want monitoring";return $true}
	$service = Get-Service -Name "HealthService" -ErrorAction SilentlyContinue
	if(!$service -and $returnedStatus){
		Write-Verbose "Microsoft Monitoring Agent service not installed.`r`nTEST:FAILED"
		$returnedStatus = $false
	}
	else {Write-Verbose "Microsoft Monitoring Agent service is installed."}
	if($service.Status -ne "Running" -and $returnedStatus){
		Write-Verbose "Microsoft Monitoring Agent service is not running.`r`nTEST:FAILED"
		$returnedStatus = $false
	}
	elseif($returnedStatus) {Write-Verbose "Microsoft Monitoring Agent service is running."}
	if($returnedStatus){
		if($primaryWorkspaceID){
			try{
				$healthService = New-Object -ComObject 'AgentConfigManager.MgmtSvcCfg'
				if($($healthService.GetCloudWorkspace($primaryWorkspaceID)) -eq $null){
					Write-Verbose "Primary workspace is NOT present.`r`nTEST:FAILED"
					$returnedStatus = $false
				} 
				else {Write-Verbose "Primary workspace is present."}
			}
			catch{
				Write-Verbose "Error checking the primary workspace:$($_.Exception.Message)`r`nTEST:FAILED"
				$returnedStatus = $false
			}
		}
		if($secondaryWorkspaceID){
			try{
				if(!$healthService){$healthService = New-Object -ComObject 'AgentConfigManager.MgmtSvcCfg'}
				if($($healthService.GetCloudWorkspace($secondaryWorkspaceID)) -eq $null){
					Write-Verbose "Secondary workspace is NOT present.`r`nTEST:FAILED"
					$returnedStatus = $false
				} else {Write-Verbose "Secondary workspace is already present."}
			}
			catch{
				Write-Verbose "Error configuring the secondary workspace:$($_.Exception.Message)`r`nTEST:FAILED"
				$returnedStatus = $false
			}
		}
	}
	return $returnedStatus
}
function Set-OMSWorkspaces {
	param(
		[string] $primaryWorkspaceID,
		[string] $primaryWorkspaceKey,
		[string] $secondaryWorkspaceID,
		[string] $secondaryWorkspaceKey
	    )
	if(!$primaryWorkspaceID -and !$secondaryWorkspaceID){
		Write-Verbose -Message "Customer doen't want monitoring. Doing nothing..."
	}
	else{
		if(!(Test-Path "C:\temp\oms\MMASetup-AMD64.exe")){
			Write-Verbose -Message "Downloading latest OMS agent..."
			New-Item -ItemType Directory -Path "C:\temp\oms" -Force -ErrorAction SilentlyContinue | Out-Null
			wget -Uri "http://download.microsoft.com/download/3/1/7/317DCEEB-5E48-47B0-A849-D8A2B1D7795C/MMASetup-AMD64.exe" -OutFile "C:\temp\oms\MMASetup-AMD64.exe" 
		}
		$service = Get-Service -Name "HealthService" -ErrorAction SilentlyContinue
		if(!$service){
			Write-Verbose "Installing the agent bits"
			Start-Process -FilePath "C:\Temp\oms\MMASetup-AMD64.exe" -ArgumentList "/Q:A /R:N /C:`"setup.exe /qn AcceptEndUserLicenseAgreement=1`"" -wait
			sleep 15
		}
		$service = Get-Service -Name "HealthService" -ErrorAction SilentlyContinue
		if($service.Status -ne "Running"){
			Write-Verbose "Starting the service."
			Start-Service -Name "HealthService"
			sleep 15
			$service = Get-Service -Name "HealthService" -ErrorAction SilentlyContinue
		}
		if($service.Status -eq "Running"){
			#if primary stuff is null skip this try statement
			if($primaryWorkspaceID){
				try{
					$healthService = New-Object -ComObject 'AgentConfigManager.MgmtSvcCfg'
					if($($healthService.GetCloudWorkspace($primaryWorkspaceID)) -eq $null){
						Write-Verbose "Adding the primary workspace to the configuration and reloading the config."
						$healthService.AddCloudWorkspace($primaryWorkspaceID,$primaryWorkspaceKey)
						$healthService.ReloadConfiguration()
						sleep 30
						$healthService = $null
						$healthService = New-Object -ComObject 'AgentConfigManager.MgmtSvcCfg'
					} else {Write-Verbose "primary workspace is already present."}
				}
				catch{
					Write-Verbose "Error configuring the primary workspace:$($_.Exception.Message)"
				}
			}
			# initialize the health service
			if($secondaryWorkspaceID){
				try{
					if(!$healthService){$healthService = New-Object -ComObject 'AgentConfigManager.MgmtSvcCfg'}
					if($($healthService.GetCloudWorkspace($secondaryWorkspaceID)) -eq $null){
						Write-Verbose "Adding the secondary workspace to the configuration and reloading the config."
						$healthService.AddCloudWorkspace($secondaryWorkspaceID,$secondaryWorkspaceKey)
						$healthService.ReloadConfiguration()
						sleep 30
						$healthService = $null
						$healthService = New-Object -ComObject 'AgentConfigManager.MgmtSvcCfg'
					} else {Write-Verbose "Secondary workspace is already present."}
				}
				catch{
					Write-Verbose "Error configuring the secondary workspace:$($_.Exception.Message)"
				}
			}
			foreach($workspace in $($healthService.GetCloudWorkspaces())){
				Write-Verbose "$($workspace.workspaceId) is configured on the agent with a status of:$($workspace.ConnectionStatusText)"
			}
		}
	}
}
export-modulemember -function Test-OMSWorkspaces,Set-OMSWorkspaces